class Enemy {
  constructor(x, y, movement) {
   
    this.x = x;
    this.y = y;
    this.movement = movement;

    this.sprite = 'images/enemy-bug.png';
  }


  update(dt) {
   
    this.x += this.movement * dt;

    if (this.x > 500) {
      this.x = -150;
      this.movement = 150 + Math.floor(Math.random() * 500);
    }

    if (player.x < this.x + 60 &&
      player.x + 37 > this.x &&
      player.y < this.y + 25 &&
      30 + player.y > this.y) {
      player.x = 200; 
      player.y = 400; 
    }
  };
  render() {
    ctx.drawImage(Resources.get(this.sprite), this.x, this.y);
  };
}




class Player {
  constructor(x, y, movement) {
    this.x = x;
    this.y = y;
    this.movement = movement;
    this.sprite = 'images/char-boy.png';
  }
  update() {
    if (this.y > 380) {
      this.y = 380;
    }

    if (this.x > 400) {
      this.x = 400;
    }

    if (this.x < 0) {
      this.x = 0;
    }
  };

  render() {
    ctx.drawImage(Resources.get(this.sprite), this.x, this.y);
  };

  handleInput(keyPress) {
    switch (keyPress) {
      case 'left':
        this.x -= this.movement + 50;
        break;
      case 'up':
        this.y -= this.movement + 30;
        break;
      case 'right':
        this.x += this.movement + 50;
        break;
      case 'down':
        this.y += this.movement + 30;
        break;
    }
  };
}


let allEnemies = [];

let enemyPosition = [50, 135, 220];
let player = new Player(200, 400, 50);
let enemy;

enemyPosition.forEach(function (posY) {
  enemy = new Enemy(0, posY, 100 + Math.floor(Math.random() * 499));
  allEnemies.push(enemy);
});

document.addEventListener('keyup', function (e) {
  var allowedKeys = {
    37: 'left',
    38: 'up',
    39: 'right',
    40: 'down'
  };

  player.handleInput(allowedKeys[e.keyCode]);
});