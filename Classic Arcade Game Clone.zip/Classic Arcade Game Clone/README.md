# Classic Arcade Game Clone 
# this project aime to ahmed gamal
# game for Ntl


 ## Languages or Tools used

* HTML & CSS
* HTML5 Canvas
* JavaScript

## Getting started
Open the index.html file in any modern browser, click inside the game area, and enjoy playing the game.

 



