# THE THREE PROJECT OF NTL (Memory Game)

An memory game for toddlers to play. This project was entirely create with HTML, CSS and Javascript (no JS and CSS frameworks).

