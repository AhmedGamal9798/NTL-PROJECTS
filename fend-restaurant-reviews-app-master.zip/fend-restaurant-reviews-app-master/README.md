my 5_project for NTL (resturant reviews)
# Project Instructions
this project, a static webpage that lacks accessibility is given to be converted into a mobile-ready web application. The design  must be responsive on different sized displays and accessible for screen reader use. It will also be added a service worker to begin the process of creating a seamless offline experience for the users.

# made by
this project made by ahmed

 



