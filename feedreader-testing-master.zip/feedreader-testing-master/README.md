<h1>Feed Reader Testing - FEND Project 5 OF NTL</h1>
<h3>By: AHMED GAMAL</h3>
<br/>
<h4>View Project</h4>
<hr>
<br/>
<h4>Tests</h4> 
<hr>
<p>RSS Feeds:</p>
<ul>
	<li>Test feeds are defined</li>
	<li>Test feed URLs are defined and contain content</li>
	<li>Test feed names are defined and contain content</li>
</ul>
<p>Menu:</p>
<ul>
	<li>Test is hidden on page load</li>
	<li>Test menu icon appears on click</li>
</ul>
<p>First RSS Entry:</p>
<ul>
	<li>Test at least one entry displays on load after async call</li>
</ul>
<p>RSS Entry Change:</p>
<ul>
	<li>Test RSS entry changes on menu select</li>
</ul>
<br/>

